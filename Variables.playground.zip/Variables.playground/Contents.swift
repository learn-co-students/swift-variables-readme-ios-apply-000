var favoriteCharacter = "Jon Snow"
print(favoriteCharacter)

favoriteCharacter = "Tyrion Lannister"
print(favoriteCharacter)

favoriteCharacter = "definitely Jon Snow"

let ultimateFavoriteCharacter = "Arya Stark"
print(ultimateFavoriteCharacter)

ultimateFavoriteCharacter

